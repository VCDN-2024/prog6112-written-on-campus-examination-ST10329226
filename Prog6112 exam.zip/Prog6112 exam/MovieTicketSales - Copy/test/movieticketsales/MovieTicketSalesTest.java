
package movieticketsales;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MovieTicketSalesTest {

    @Test
    public void testCalculateTotalMovieSales() {
        MovieTicketSales.MovieTickets mt = new MovieTicketSales.MovieTickets();
        int[][] ticketSales = {
                {3000, 1500, 1700},
                {3500, 1200, 1600}
        };
        int[] expectedSales = {6200, 6300}; 
        int[] actualSales = mt.calculateTotalMovieSales(ticketSales);
        assertArrayEquals(expectedSales, actualSales);
    }

    @Test
    public void testTopPerformingMovie() {
        MovieTicketSales.MovieTickets mt = new MovieTicketSales.MovieTickets();
        int[] totalSales = {6200, 6300};
        String[] movieNames = {"Napoleon", "Oppenheimer"};
        String expectedTopMovie = "Oppenheimer";
        String actualTopMovie = mt.topPerformingMovie(totalSales, movieNames);
        assertEquals(expectedTopMovie, actualTopMovie);
    }
}