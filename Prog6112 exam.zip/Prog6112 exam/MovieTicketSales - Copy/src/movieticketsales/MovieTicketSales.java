
package movieticketsales;


public class MovieTicketSales {

    public static void main(String[] args) {
        String[] movieNames = {"Napoleon", "Oppenheimer"};
        int[][] ticketSales = {
                {3000, 1500, 1700},
                {3500, 1200, 1600}
        };

        MovieTickets mt = new MovieTickets();
        int[] totalSales = mt.calculateTotalMovieSales(ticketSales);
        String topMovie = mt.topPerformingMovie(totalSales, movieNames);

        // Output the report 
        System.out.println("MOVIE TICKET SALES REPORT - 2024");
        System.out.println("----------------------------");
        System.out.println("JAN\tFEB\tMAR");

        for (int i = 0; i < movieNames.length; i++) {
            System.out.print(movieNames[i] + "\t");
            for (int j = 0; j < ticketSales[i].length; j++) {
                System.out.print(ticketSales[i][j] + "\t");
            }
            System.out.println();
        }

        for (int i = 0; i < movieNames.length; i++) {
            System.out.println("Total movie ticket sales for " + movieNames[i] + ": " + totalSales[i]);
        }

        System.out.println("Top performing movie: " + topMovie);
    }

    // Interface
    interface IMovieTickets {
        int[] calculateTotalMovieSales(int[][] ticketSales);
        String topPerformingMovie(int[] totalSales, String[] movieNames);
    }

    // MovieTickets class
    static class MovieTickets implements IMovieTickets {

        @Override
        public int[] calculateTotalMovieSales(int[][] ticketSales) {
            int[] totalSales = new int[ticketSales.length];
            for (int i = 0; i < ticketSales.length; i++) {
                for (int j = 0; j < ticketSales[i].length; j++) {
                    totalSales[i] += ticketSales[i][j];
                }
            }
            return totalSales;
        }

        @Override
        public String topPerformingMovie(int[] totalSales, String[] movieNames) {
            int maxIndex = 0;
            for (int i = 1; i < totalSales.length; i++) {
                if (totalSales[i] > totalSales[maxIndex]) {
                    maxIndex = i;
                }
            }
            return movieNames[maxIndex];
        }
    }
}
