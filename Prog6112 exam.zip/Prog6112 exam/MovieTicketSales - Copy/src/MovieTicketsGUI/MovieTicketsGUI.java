
package MovieTicketsGUI;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;

// IMovieTickets Interface
interface IMovieTickets {
    double calculateTotalTicketPrice(int numberOfTickets, double ticketPrice);
    boolean validateData(MovieTicketData movieTicketData); 
}

// MovieTicketData Class (for holding movie ticket information)
class MovieTicketData {
    String movieName;
    int numberOfTickets;
    double ticketPrice;

    public MovieTicketData(String movieName, int numberOfTickets, double ticketPrice) {
        this.movieName = movieName;
        this.numberOfTickets = numberOfTickets;
        this.ticketPrice = ticketPrice;
    }
}

public class MovieTicketsGUI extends JFrame implements ActionListener {

    private JComboBox<String> movieComboBox;
    private JTextField numTicketsField, ticketPriceField;
    private JTextArea ticketReportArea;

    // MovieTickets Class implementing IMovieTickets
    static class MovieTickets implements IMovieTickets {
        @Override
        public double calculateTotalTicketPrice(int numberOfTickets, double ticketPrice) {
            double totalPrice = numberOfTickets * ticketPrice;
            double vat = totalPrice * 0.14; // 14% VAT
            return totalPrice + vat;
        }

        @Override
        public boolean validateData(MovieTicketData movieTicketData) {
            if (movieTicketData.movieName == null || movieTicketData.movieName.isEmpty()) {
                return false; 
            }
            if (movieTicketData.ticketPrice <= 0) {
                return false; 
            }
            if (movieTicketData.numberOfTickets <= 0) {
                return false;
            }
            return true; 
        }
    }


    public MovieTicketsGUI() {
        // Set up the frame
        setTitle("MOVIE TICKETS");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the frame

        // Create components
        JLabel movieLabel = new JLabel("MOVIE:");
        movieComboBox = new JComboBox<>(new String[]{"Napoleon", "Oppenheimer", "Damsel"});
        JLabel numTicketsLabel = new JLabel("NUMBER OF TICKETS:");

        numTicketsField = new JTextField();
        numTicketsField.setPreferredSize(new Dimension(150, 25)); // Set preferred size

        JLabel ticketPriceLabel = new JLabel("TICKET PRICE:");

        ticketPriceField = new JTextField();
        ticketPriceField.setPreferredSize(new Dimension(150, 25)); // Set preferred size

        JButton processButton = new JButton("Process");
        processButton.addActionListener(this); 
        ticketReportArea = new JTextArea(10, 30);
        ticketReportArea.setEditable(false);

        // Layout components using GridBagLayout
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // Add some spacing

        gbc.gridx = 0;
        gbc.gridy = 0;
        add(movieLabel, gbc);
        gbc.gridx = 1;
        add(movieComboBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(numTicketsLabel, gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL; // Fill horizontally
        add(numTicketsField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(ticketPriceLabel, gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL; // Fill horizontally
        add(ticketPriceField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2; // Span 2 columns
        gbc.fill = GridBagConstraints.HORIZONTAL; 
        add(processButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0; // Allow the text area to expand
        add(new JScrollPane(ticketReportArea), gbc); 

        // Create menu bar
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitMenuItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processMenuItem = new JMenuItem("Process");
        processMenuItem.addActionListener(this);
        JMenuItem clearMenuItem = new JMenuItem("Clear");
        clearMenuItem.addActionListener(e -> clearFields()); 
        toolsMenu.add(processMenuItem);
        toolsMenu.add(clearMenuItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            String movieName = (String) movieComboBox.getSelectedItem();
            int numTickets = Integer.parseInt(numTicketsField.getText());
            double ticketPrice = Double.parseDouble(ticketPriceField.getText());

            // Create MovieTicketData object
            MovieTicketData movieTicketData = new MovieTicketData(movieName, numTickets, ticketPrice);

            // --- Validation using MovieTickets class ---
            MovieTickets validator = new MovieTickets(); 
            if (!validator.validateData(movieTicketData)) {
                throw new IllegalArgumentException("Invalid input data. Please check your entries.");
            }

            // --- Calculate total price using MovieTickets class ---
            double totalWithVat = validator.calculateTotalTicketPrice(numTickets, ticketPrice); 

            // Format the report
            String report = "MOVIE TICKET REPORT\n" +
                            "MOVIE NAME: " + movieName + "\n" +
                            "MOVIE TICKET PRICE: R " + ticketPrice + "\n" +
                            "NUMBER OF TICKETS: " + numTickets + "\n" +
                            "TOTAL TICKET PRICE: R " + String.format("%.2f", totalWithVat);

            ticketReportArea.setText(report);

            // --- Save to file ---
            try (FileWriter fileWriter = new FileWriter("report.txt")) {
                fileWriter.write(report);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error saving report to file.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for tickets and price.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    private void clearFields() {
        movieComboBox.setSelectedIndex(0); // Set to the default movie
        numTicketsField.setText("");
        ticketPriceField.setText("");
        ticketReportArea.setText("");
    }

    public static void main(String[] args) {
        new MovieTicketsGUI();
    }
}